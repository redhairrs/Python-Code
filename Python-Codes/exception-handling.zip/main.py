num1=0
while num1!=100:
    try:
        num1=int(input("enter numerator"))
        num2=int(input("enter denominator"))
        num3=num1//num2
        print(num3)
    except:
        print("an error has occured")