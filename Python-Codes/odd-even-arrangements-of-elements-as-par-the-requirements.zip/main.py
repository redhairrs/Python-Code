#Step-1 :- All odd elements of A from left to right will be copied in C left to right
#Step-2 :- All even elements of A from left to right will be copied in C right to left
#Step-3 :- All odd elements of B from left to right will be copied in C left to right
#Step-4 :- All even elements of B from left to right will be copied in C right to left

A=[1, 5, 6, 8, 2, 12]
B=[3, 7, 9, 21, 14]
C=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] 

j=0 
k=10 
for i in A:
    if i%2==0:
        C[k]=i
        k=k-1
    else:
        C[j]=i
        j=j+1
        
for i in B:
    if i%2==0:
        C[k]=i
        k=k-1
    else:
        C[j]=i
        j=j+1
print(C)



