def sum(b,a=10):          # If we have set a default value, then all the variables to the right of that variable
    z=a+b                 # must be compulsorily assigned a default value but not compulsorily to the left.
    return z

a=sum(5) 
print(a)



# def sum(a=10,b):        (Here the default value to the right of 'a' i.e 'b' has not been assigned)
#     z=a+b               (So, This code would show error because of Non-Default Arguement.)
#     return z

# a=sum(5)
# print(a)


def sum(b=9,a=10,c=0):       # As long as there is no value assigned by driver, the default value will come into 
    z=a+b+c                  # account. And if a value is assigned, it will start overwriting the leftmost   
    return z                 # default value.
                             
a=sum(4)                     # (The compiler interprets the Function from left on Driver's call(like 4 will
print(a)                     #  overwrite the leftmost b=9) and a=10 and c=0 shall remain default.)


def sum(a=6,b=4):
    y=a+b
    z=a*b
    return y,z
    
a,b=sum(4,8)
print(a)
print(b)

