string=input("Enter String")
i=0
j=len(string)-1
f=0
while i<j:
    if string[i]!=string[j]:
        f=1
        break
    else:
        i=i+1
        j=j-1
if f==1:
    print("Not Pallindrome")
else:
    print("Pallindrome")
    