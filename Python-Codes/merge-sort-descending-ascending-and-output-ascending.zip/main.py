a=[]
m=int(input("Enter no. of Elements"))
for i in range(0,m,1):
    x=int(input("Enter any No."))
    a.append(x)

b=[]
n=int(input("Enter no. of Elements"))
for j in range(0,n,1):
    x=int(input("Enter any No."))
    b.append(x)
    
i=m-1
j=0
k=0
c=[]
while i>=0 and j<n:
    if a[i]<b[j]:
        c.append(a[i])
        i=i-1
        
    else:
        c.append(b[j])
        j=j+1
        
        
while i>=0:
    c.append(a[i])
    i=i-1

while j<n:
    c.append(b[j])
    j=j+1

print(c)




