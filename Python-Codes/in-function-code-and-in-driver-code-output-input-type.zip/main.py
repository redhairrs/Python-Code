def test(x):
    x=12
    print("In Function :- ",x)
    
a=20
test(a)
print("In Driver Code :- ",a)




def tst(x):
    x="Hello"
    print("In Function :- ",x)

a="Bye"
tst(a)
print("In Driver Code :- ",a)




def fn(x):
    x.append(40)
    print("In Function :- ",x)
    
a=[10,20,30]
fn(a)
print("In Driver Code :- ",a)
