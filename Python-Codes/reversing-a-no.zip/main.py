n=int(input("Enter any no."))
Res=0
Rem=0
while n>0:
    Rem=n%10
    Res=Res*10+Rem
    n=n//10
print(Res)