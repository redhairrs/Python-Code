a=[]
n=int(input("Enter no. of Elements"))
for i in range(0,n,1):
    x=int(input("Enter any No."))
    a.append(x)

i=0
s=0
while i<n:
    if a[i]%2==0:
        s=s+a[i]
    i=i+1   
print(s)
