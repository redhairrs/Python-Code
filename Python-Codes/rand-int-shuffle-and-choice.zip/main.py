import random                            # rand can show any random value exclusive of UL.
x=random.randrange(150,200)
print(int(x))

import random                            # int can show any random values inclusive of LL and UL.
y=random.randint(0,5)
print(y)

import random
l=["Hi","Bye","CU"]
random.shuffle(l)
print(l)

