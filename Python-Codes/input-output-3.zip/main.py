# If Input is -- x = [12,23,34,45,56]
# Then Output must be -- x = [56,12,23,34,45]

x=[]
n=int(input("Enter no. of Elements"))
for i in range(0,n,1):
    a=int(input("Enter any No."))
    x.append(a)

s=x[n-1]
back=n-1
while back>0:
    x[back]=x[back-1]
    back=back-1
x[0]=s
print(x)
