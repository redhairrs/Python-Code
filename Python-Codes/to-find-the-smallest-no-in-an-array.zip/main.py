x=[]
n=int(input("Enter no. of Elements"))
for i in range(0,n,1):
    a=int(input("Enter any No."))
    x.append(a)

s=x[0]
for i in range(1,n,1):
    if x[i]<s:
        s=x[i]
print(s)

