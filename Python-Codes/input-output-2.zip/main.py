# If Input is -- x = [3,4,6,0,7,8]
# Then Output must be -- x = [0,7,8,3,4,6]
# i.e. swapping is done between indeces:-
#        0-3, 1-4, 2-5

x=[]
n=int(input("Enter no. of Elements"))
for i in range(0,n,1):
    a=int(input("Enter any No."))
    x.append(a)
    
i=0
j=n//2
c=1
while c<=n//2:
    x[i],x[j]=x[j],x[i]
    i=i+1
    j=j+1
    c=c+1
print(x)
