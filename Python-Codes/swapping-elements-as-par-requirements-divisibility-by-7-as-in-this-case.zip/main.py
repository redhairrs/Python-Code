l=[12,13,21,33,14,5]
s=0
x=len(l)
i=0
while i<x:
    if l[i]%7==0:
        l[i],l[i+1]=l[i+1],l[i]
        i=i+2
    else:
        i=i+1
print(l)
