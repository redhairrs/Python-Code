from random import random
x=int(random()*5+2)
i=1
while i<=x:
    print(1,"#",end=" ")
    i=i+1
    
# This might come in Boards to tell the Output. 