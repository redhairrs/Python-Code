def tst(*a):                               # Putting a star before the variable would enclose/make the Driver's 
    print(a)                               # invoked values into a tuple
    
tst(10,23,34,45,56,67,78,89)
tst(6)




def test(a):
    return a+10,a*10,a-10
    
x=test(5)
print(x)                                     # The output in this case will also come in form of a Tuple.

    
