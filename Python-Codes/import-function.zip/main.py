                                  # FUNCTIONING OF IMPORT

# Random :-
# (This function reverts any Random value from the range 0-1. And each time on Running, it reverts different
#  fractional(decimal) values.)

from random import random                               # import random
x=random()                            #or               # x=random.random()
print(x)                                                # print(x)


# Math :-
# (There are many inbuilt Mathematical Functions like Square Root,log,cos,sin,Absolute positive value,etc which
#  cannot work simply. We need to use Import Function to import math and then we can use the inbuilt functions.)

import math
y=math.sqrt(9)
print(y)

import math                            # ('fabs' function is used to return the absolute positive value of the 
z=math.fabs(-9)                        #  inputted value.)
print(z)

import math                            # (On using int function the fabs function will return the absolute 
a=int(math.fabs(-9))                   #  positive value in integer rather than in decimals)
print(a)

