def fact(n):
    f=1
    while n>0:
        f=f*n
        n=n-1
    return f
    
n=5
r=3
t1=0                       # Function Code for the Formula of Combination Formula :- nCr = N! / R! * (N - R)!
t2=0 
t3=0
res=0
t1=fact(n)
t2=fact(r)
t3=fact(n-r)
res=t1/(t2*t3)
print(res)



