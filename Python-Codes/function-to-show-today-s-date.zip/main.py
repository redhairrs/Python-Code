import datetime
t=datetime.date.today()
print("Today is",t)


