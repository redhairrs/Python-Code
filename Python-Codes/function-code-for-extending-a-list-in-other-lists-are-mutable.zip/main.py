def test(x):
    y=[1,2,3]
    x.extend(y)
    print("In Function Code",x)
    
a=[10,12,25,34,45]
test(a)
print("In Driver Code",a)
