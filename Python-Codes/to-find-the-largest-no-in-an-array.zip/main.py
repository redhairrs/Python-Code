x=[]
for i in range(0,6,1):
    x.append(int(input("Enter No.")))
print(x)
n=len(x)
s=x[0]
for i in range(1,n,1):
    if x[i]>s:
        s=x[i]
print(s)
