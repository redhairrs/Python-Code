def test():
    print(a)
    print(b)
    
a=25                    # Global Variables (Variables in Driver Code, and not in Function code.)
b=50                    # They can be used everywhere in the Function.
test()                  # They can be accessed without sending through the parameter (test in this case)
                        # Here we did not called/invoked the Values 25 and 50 using the parameter (as
                        # we always used to do.)
                        
# This code may have worked same with the following code also :-

def tst(a,b):
    print(a)
    print(b)
    
tst(25,50)
