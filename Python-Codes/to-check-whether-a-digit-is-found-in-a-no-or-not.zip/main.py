n=int(input("Enter No."))
d=int(input("Enter Digit"))
flag=0
rem=0
while n>0:
    rem=n%10
    if rem==d:
        flag=1
        break
    else:
        n=n//10
if flag==1:
    print("Found")
else:
    print("Not Found")
    