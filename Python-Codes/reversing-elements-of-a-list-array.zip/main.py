x=[]
n=int(input("Enter no. of Elements"))
for i in range(0,n,1):
    a=(int(input("Enter any No."))
    x.append(a)
    
i=0
j=n-1
c=1
while c<=n//2:
    x[i],x[j]=x[j],x[i]
    i=i+1
    j=j-1
    c=c+1
print(x)

