# When we create a variable inside a function, it is local by default.

# When we define a variable outside of a function, it is global by default. You don't have to use global keyword.

# We use global keyword to read and write a global variable inside a function.

# Use of global keyword outside a function has no effect.

# Once a variable is declared global inside the Function, it can't be changed/manipulated ever in that Function.

# Even after we declare a Global variable in the Function code,then that same variable's value(as in the Function) 
# would be changed for the Driver code as well. (Because afterall Global Variables' value can't be changed.)



                                         # 1
def tst():
    global a
    a=[1,2,3]
    b=[4,5,6]
    print("In Fn. code : ",a)
    print("In Fn. code : ",b)
    
a=[25]
b=[50]
tst()
print("In Driver code : ",a)
print("In Driver code : ",b)



                                         # 2

def test():
    global a
    a=-40
    print("In Fn. code : ",a)
    
a=50
test()
print("In Driver code : ",a)
 
 
 
 
                                         # 3
 
def test1():
    global a
    a=100
    print("In Fn. code : ",a)
    
def test2():
    a=500
    print("In Fn. code : ",a)
    
a=0
test1()
print("In Driver code : ",a)
test2()
print("In Driver code : ",a)

