# If Input is -- x = [12,23,34,45,56]
# Then Output must be -- x = [23,34,45,56,12]

x=[]
n=int(input("Enter No. of Elements"))
for i in range(0,n,1):
    a=int(input("Enter any No."))
    x.append(a)
 
s=x[0]   
back=0
while back<n-1:
    x[back]=x[back+1]
    back=back+1
x[n-1]=s
print(x)