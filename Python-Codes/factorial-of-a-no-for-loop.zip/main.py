n=int(input("Enter No."))
f=1
for i in range(1,n+1,1):
    f=f*i
print("Factorial is :-",f)
