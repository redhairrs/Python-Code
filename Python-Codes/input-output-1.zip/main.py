# If Input is -- x = [3,4,6,0,7,8]
# Then Output must be -- x = [4,3,0,6,8,7]

x=[]
n=int(input("Enter no. of Elements"))
for i in range(0,n,1):
    a=int(input("Enter any No."))
    x.append(a)
    
i=0
j=1
c=1
while c<=n//2:
    x[i],x[j]=x[j],x[i]
    i=i+2
    j=j+2
    c=c+1
print(x)
