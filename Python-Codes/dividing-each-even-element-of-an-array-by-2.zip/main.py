a=[]
for i in range(0,6,1):
    a.append(int(input("Enter No.")))
print(a)

s=[i//2 for i in a if i%2==0]
print(s)