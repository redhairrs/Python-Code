def cir_area(r):
    return 3.14*r*r
    
def sq_area(s):
    return s*s
    
def rect_area(l,b):
    return l*b
    
r=int(input("Enter Radius"))
print(cir_area(r))
s=int(input("Enter Side"))
print(sq_area(s))
l=int(input("Enter Length"))
b=int(input("Enter Breadth"))
print(rect_area(l,b))


                                            # Or


import math
def cir_area(r):
    return math.pi*r*r
    
def sq_area(s):
    return s*s
    
def rect_area(l,b):
    return l*b
    
r=int(input("Enter Radius"))
print(cir_area(r))
s=int(input("Enter Side"))
print(sq_area(s))
l=int(input("Enter Length"))
b=int(input("Enter Breadth"))
print(rect_area(l,b))