n=int(input("Enter a number: "))
p=0
x=n
rem=0
res=0
pr=0
while n>0:
    n=n//10
    p=p+1
n=x
while n>0:
    rem=n%10
    pr=rem**p
    res=res+pr
    n=n//10
if x==res:
    print("Armstrong")
else:
    print("Not Armstrong")
    
