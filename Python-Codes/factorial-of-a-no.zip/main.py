n=int(input("Enter No."))
f=1
while n>0:
    f=f*n
    n=n-1
print(f)