n=int(input("Enter any No."))
i=1
while i<=10:
    print(n*i,)
    i=i+1
    
