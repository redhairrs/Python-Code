a=[]
m=int(input("Enter no. of Elements"))
for i in range(0,m,1):
    x=int(input("Enter any No."))
    a.append(x)

b=[]
n=int(input("Enter no. of Elements"))
for j in range(0,n,1):
    x=int(input("Enter any No."))
    b.append(x)
    
i=0
j=n-1
k=0
c=[]
while i<m and j>=0:
    if a[i]<b[j]:
        c.append(a[i])
        i=i+1
        
    else:
        c.append(b[j])
        j=j-1
        
        
while i<m:
    c.append(a[i])
    i=i+1

while j>=0:
    c.append(b[j])
    j=j-1

print(c)





