l1=[1,2,3]
l2=[4,5,6]
print(l1+list("strings"))

