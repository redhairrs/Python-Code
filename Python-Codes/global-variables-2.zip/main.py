def test():
    a=600            # Integers are Immutable (and so in this case the function code will not print
    b=1200           # values as asked by the driver code and rather create its own memory block.)
    print(a,b)       # Hence, the output will come out to be :- 600 1200 instead of 25 50.
    
a=25                 # Global Variables can be used/accessed in any function, but
b=50                 # cannot be manipulated/changed.
test()
print(a,b)

# Cannot be manipulated but can be used/accessed which means :-
# for example :-

# def tst():
#   print(a+b)
#   print(b)
#   print(a)
#
# a=25
# b=50
# test()           # (In this case, since we are not trying to change/mutate the Global Variables,
                   #  so, the output will simply come aout to be :- 75,50,25)
                   