num1=0
while num1!=100:
    try:
        num1=eval(input("enter numerator"))
        num2=eval(input("enter denominator"))
        num3=num1//num2
        print(num3)
    except:print("an error has occured")

   
