def test():    #(DEFINING FUNCTION)
    print("Hello")   
    print(pow(2,4))  
    print("Bye")
test()                          # This shall revert the output in the function 2 times because we(driver) have 
test()   #(CALLING/INVOKING)    # invoked(called) 2 Times.




def sum(a,b):
    z=a+b        # PROCESSING PHASE (LOGIC)
    print(z)                                            # (Compiler First interpret the Driver's Call 
                                                        #  and then go up towards the last)
sum(2,3)        # INPUT PHASE
sum(8,1)
sum(0,0)         




def sum(p,q):
    x=p+q         # Return will not print the outut in the Function instead, it would return the Output Phase to
    return x      # us(driver) and we can use it in anyway(display the sum simply, display Double of the sum,etc.)
    
s=sum(2,5)
print(s)          # Until and Unless we dont return the value, we can't use it to display output as 
z=(2*sum(2,3))    # par our requirement.
print(z)

