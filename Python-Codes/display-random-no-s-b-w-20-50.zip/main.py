from random import random
x=random()*30+20
print(int(x))

# To display Random Values between a particular Range:
# FORMULA :-

#   1st find - Difference(D) = Upper Limit(UL) - Lower Limit(LL)
#   so,
#       random()*D+LL gives us the random value from the range LL to UL

