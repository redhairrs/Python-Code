l=[-12,11,-13,-5,6,-7,5,-3,-6]
n=len(l)
print("Original List was :- ",l)
for i in range(n-1):
    for j in range(n-1,0,-1):
        if l[j]<0:
            l[i],l[i+1]=l[i+1],l[i]
print("Reversed List is :- ",l)
