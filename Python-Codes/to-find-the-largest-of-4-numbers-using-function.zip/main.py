def large(x,y):
    if x>y:
        return x
    else:
        return y


a=15
b=12
c=6
d=11
t1=0
t2=0
t3=0
t1=large(a,b)
t2=large(c,d)
t3=large(t1,t2)
print(t3)