l1=[500,600]
l2=[35,65]

l1.append(700)
l1.extend(l2)
l1.insert(2,13)
print(l1)

print(l1+l2)

print(l1)

print(l1.index(35))

print(l2*5)
