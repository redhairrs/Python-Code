import math as ganit
print(ganit.pi)



import math as ganit               # This code will show Error
print(math.pi)